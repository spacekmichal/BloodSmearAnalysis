%% erosion of image - smoothing
seD = strel('diamond',2);
binarSmooth = imerode(binar,seD);
binarSmooth = imerode(binarSmooth,seD);
%binarSmooth = imerode(binarSmooth,seD);
imshow(binarSmooth)
title('Segmented Image');

%% dm

distMap = bwdist(~binarSmooth, 'euclidean');
figure
imshow(distMap, [])