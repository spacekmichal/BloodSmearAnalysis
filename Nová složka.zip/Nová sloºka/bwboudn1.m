clear all; close all; clc
im= im2double(imread('image-10.png'));
figure 
imshow (im)
im_r=im(:,:,1);
im_g=im(:,:,2);
im_b=im(:,:,3);

i= im_r-im_b;
%% PŘEVOD NA BINAR
img=i;
figure
imshow(img)

gt = graythresh(img);
binar = imbinarize(img, gt);
imshowpair(img, binar, 'montage')
%%
seD = strel('sphere',4);
binarSmooth = imerode(binar,seD);
binarSmooth = imerode(binarSmooth,seD);
distMap = bwdist(~binarSmooth, 'euclidean');
figure
imshow(distMap, [])
%%
img2= imfill(binarSmooth,'holes');
B = bwboundaries(img2);
figure
imshow(img2)
text(10,10,strcat('\color{green}Objects Found:',num2str(length(B))))
hold on

for k = 1:length(B)
boundary = B{k};
plot(boundary(:,2), boundary(:,1), 'g', 'LineWidth', 0.2)
end
