clear all; close all; clc
im= im2double(imread('image-32.png'));
figure 
imshow (im)
im_r=im(:,:,1);
im_g=im(:,:,2);
im_b=im(:,:,3);

i= im_r-im_b;
%% PŘEVOD NA BINAR
img=i;
figure
imshow(img)

gt = graythresh(img);
binar = imbinarize(img, gt);
imshowpair(img, binar, 'montage')
%% DIST MAPA

bw=binar;

rozodi=watershed(bw);
negativ=1-bw;
mapa=bwdist(negativ);
mapa=-mapa;
mapa(mapa==0)=-Inf;
bw2=watershed(mapa);

figure
subplot(141)
imshow(bw,[])
title('Puvodní obrazek')
subplot(142)
mesh(bwdist(1-bw))
title('Distanční mapai')
subplot(143)
mesh(mapa)
title('upravená distanční mapa')
subplot(144)
imshow(label2rgb(bw2),[])
title('Segmentace obrazu')

%% Chan-Vese
img4 = activecontour(binar, bw ,200, 'Chan-Vese'); hold on
visboundaries(img4); 

figure
imshow(labeloverlay(im, img4));

%% erosion of image - smoothing
seD = strel('diamond',2);
binarSmooth = imerode(binar,seD);
binarSmooth = imerode(binarSmooth,seD);
%binarSmooth = imerode(binarSmooth,seD);
imshow(binarSmooth)
title('Segmented Image');

%% dm

distMap = bwdist(~binarSmooth, 'euclidean');
figure
imshow(distMap, [])

%%
n=20;
klist=2:n;%the number of clusters you want to try
myfunc = @(X,K)(kmeans(X, K));
eva = evalclusters(net.IW{1},myfunc,'CalinskiHarabasz','klist',klist);
classes=kmeans(net.IW{1},eva.OptimalK);

