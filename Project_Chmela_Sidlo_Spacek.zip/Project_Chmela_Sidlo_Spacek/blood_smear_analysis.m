clear all; close all; clc
%% NAČTENÍ POČÁTEČNÍCH PROMĚNNÝCH
obrazky=[1,2,4,7,8,10,11,12,14,17,18,19,20,21,22,23,24,25,28,30,31,32,33,34,35,36,37,38,39,43,44,45,46,48,49,50,51,52,53,54];
pocet_cervenych=[];
pocet_bilych=[];
%% CYKLUS PRO PRŮCHOD CELÝM DATASETEM
for k=1:length(obrazky)
%% NAČTENÍ OBRÁZKU     
cislo=string(obrazky(k));
nazev='image-'+cislo+'.png';
img= im2double(imread(nazev));

% figure 
% imshow (im)

%% ROZDĚLENÍ OBRAZU NA JEDNOTLIVÉ KANÁLY

im_r=img(:,:,1);
im_g=img(:,:,2);
im_b=img(:,:,3);

%% PRO ČERVENÉ KRVINKY

img_C= im_r-im_b;

% figure
% imshow(img_C)
%% PŘEVOD NA BINARNÍ OBRAZ

gt=graythresh(img_C);
binar = imbinarize(img_C, 0.11);
if gt<0.01
    img_C = (img_C - min(img_C(:))) / (max(img_C(:)) - min(img_C(:)));
    gt=graythresh(img_C);
    binar = imbinarize(img_C, gt);
end

% imshowpair(img_C, binar, 'montage')
%% GENERACE STREL PRO DETEKCI
se = strel('disk',2);
closeBW = imclose(binar,se);

% figure, imshow(closeBW)

closeBW=medfilt2(closeBW,[5,5]);
a=imfill(closeBW,'holes');

% figure
% imshow(a)

% zvětšení obrazu pro lepší detekci na okrajích
b=padarray(a,[50,50]);


%% DETEKCE JEDNOTLIVÝCH ČERVENÝCH KRVINEK
hrany=edge(b,"canny");

% figure
% imshow(hrany)

[centersBright_C,radiiBright_C] = imfindcircles(hrany,[20 45], ...
            'ObjectPolarity','bright','Sensitivity',0.91,'Method','TwoStage','EdgeThreshold',(gt./1.9));

%% úprava vektoru středů pro minimalizaci falešných detekcí 

stredy=[];
polomery=[];

for i=1:size(centersBright_C,1)
    x=round(centersBright_C(i,1));
    y=round(centersBright_C(i,2));
        if imbinarize(sum(sum(b(y-5:y+5,x-5:x+5))),30)==1
            stredy(i,1)=centersBright_C(i,1);
            stredy(i,2)=centersBright_C(i,2);
            polomery(1,i)=radiiBright_C(i);
        end
end
figure
imshow(img)
viscircles(stredy-50, polomery,'Color','b');
pocet_C= size(stredy,1);

%% ALGORITMUS PRO BÍLÉ KRVINKY

% prahování šedotónového obrazku na 4 skupiny
qt = imquantize(img,multithresh(rgb2gray(img)));

%figure
%imshow(qt,[]);

p = zeros(256);

% přepis do nové proměnné pro následnou úpravu
for i = 1:size(qt,1)
    for j = 1:size(qt,2)
        if qt(i,j) == 1
            p(i,j) = qt(i,j);
        end
    end
end

% figure
% imshow(p)

%% filtrace pro hladký obraz

p_filt = medfilt2(p,[10,10]);
p_filt = bwareaopen(p_filt,2000);
p_filt = imfill(p_filt,'holes');

%zvětšení obrazu pro lepší detekci na okrajích

zvetseny_vstup = padarray(p_filt,[50,50]);

% figure
% imshow(p_filt);
%figure
%imshow(zvetseny_vstup);

%% DETEKCE JEDNOTLIVÝCH BUNĚK

hrany=edge(zvetseny_vstup,"canny");

% figure
% imshow(hrany)

[centersBright_B,radiiBright_B] = imfindcircles(hrany,[15 45], ...
            'ObjectPolarity','bright','Sensitivity',0.95,'Method','TwoStage','EdgeThreshold',(0.11/1.9));

%% úprava vektoru středů pro minimalizaci falešných detekcí    

stredy=[];
polomery=[];
for l=1:size(centersBright_B,1)
    x=round(centersBright_B(l,1));
    y=round(centersBright_B(l,2));
        if imbinarize(sum(sum(zvetseny_vstup(y-5:y+5,x-5:x+5))),50)==1
            stredy(l,1)=centersBright_B(l,1);
            stredy(l,2)=centersBright_B(l,2);
            polomery(1,l)=radiiBright_B(l);
        end
end

stred=stredy;
polomer=polomery;

if size(stredy,1)>1
    stred=[];
    polomer=[];
    [velikost,pozice]=max(polomery);
    stred=stredy(pozice,:);
    polomer=35;
end

viscircles(stred-50, polomer,'Color','r');
pocet_B=size(stred,1);

%% ZÁPIS DO VEKTORŮ PRO VYHODNOCENÍ

pocet_cervenych(k)=pocet_C;
pocet_bilych(k)=pocet_B;
end